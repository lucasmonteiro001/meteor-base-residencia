# The Meteor Chef - Base
A starting point for Meteor apps.

<table>
  <tbody>
    <tr>
      <th>Base Version</th>
      <td>v4.0.0</td>
    </tr>
    <tr>
      <th>Meteor Version</th>
      <td>v1.3.2.4</td>
    </tr>
  </tbody>
</table>

[Read the Documentation](http://themeteorchef.com/base)
