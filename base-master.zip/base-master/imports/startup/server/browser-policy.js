// e.g., BrowserPolicy.content.allowOriginForAll( 's3.amazonaws.com' );
