import '../../api/documents/methods.js';
import '../../api/documents/server/publications.js';
